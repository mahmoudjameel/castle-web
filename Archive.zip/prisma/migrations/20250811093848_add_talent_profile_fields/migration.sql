-- AlterTable
ALTER TABLE "User" ADD COLUMN     "accent" TEXT,
ADD COLUMN     "eyeColor" TEXT,
ADD COLUMN     "features" TEXT,
ADD COLUMN     "hairColor" TEXT,
ADD COLUMN     "hairStyle" TEXT,
ADD COLUMN     "height" INTEGER,
ADD COLUMN     "language" TEXT,
ADD COLUMN     "skinColor" TEXT,
ADD COLUMN     "weight" INTEGER;
